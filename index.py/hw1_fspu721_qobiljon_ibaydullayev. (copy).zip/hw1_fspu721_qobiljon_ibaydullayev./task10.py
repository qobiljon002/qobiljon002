a=int(input('enter first number.'))
b=int(input('enter second number.'))
c=int(input('enter third number.'))
d=int(input('enter fourth number.'))
if a>b:
       print('a,max')
       print('b,min')
elif a>c:
       print('a,max')
       print('c,min')
       a>d:  
       print('a,max')
       print('d,min')
else:  print('d,max')




