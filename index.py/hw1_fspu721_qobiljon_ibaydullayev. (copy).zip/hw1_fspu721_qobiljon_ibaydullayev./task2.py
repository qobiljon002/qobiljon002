x=int(input('enter first number:'))
y=int(input('enter second number:'))
if x==y:print('entered numbers are equal:')
else:print('entered numbers are not equal:')
