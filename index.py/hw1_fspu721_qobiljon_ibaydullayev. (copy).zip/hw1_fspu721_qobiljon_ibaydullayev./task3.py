a=int(input('enter the desired number.'))
if a>0: print('entered number is positive number.')
else: print('entered number is negative number.')