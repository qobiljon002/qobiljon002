a=int(input('enter the desired number.'))
if a>0:print(a**0.5)
elif a<0: print('enter positive number.')