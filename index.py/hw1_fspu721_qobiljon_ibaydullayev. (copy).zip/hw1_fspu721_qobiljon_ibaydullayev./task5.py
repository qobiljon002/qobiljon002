a=int(input(' Enter desired number.'))
if a>0: print(a-10)
elif a<0: print(a+10)