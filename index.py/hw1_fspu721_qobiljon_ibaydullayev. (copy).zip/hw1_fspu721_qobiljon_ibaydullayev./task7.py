a=int(input('Enter desired number.'))
if 5<a<10:print('true.')
else:print('false.')