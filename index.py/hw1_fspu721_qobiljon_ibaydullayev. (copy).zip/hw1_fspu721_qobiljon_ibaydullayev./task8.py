a=int(input('Enter desired number.'))
if a%2==1:print('toq son.')
else:print('juft son.')