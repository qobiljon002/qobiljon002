i=1
while i<=10:
    print(i, 'ning kvadrati' ,i**2, 'ga teng.')
    i+=1
