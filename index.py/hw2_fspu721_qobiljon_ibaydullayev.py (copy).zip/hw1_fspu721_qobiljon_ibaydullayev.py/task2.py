i=1
sum=0
while i<=100:
    sum+=i 
    print(sum)
    i+=1
      