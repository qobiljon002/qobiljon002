i=1
while i<=3:
    num=int(input('son kiriting'))
    if num>0:print(num,'musbat son.')
    else:print('manfiy son.')
    i+=1    


    
        
        

    
        