product=1
i=1
while i<=1000:
    product*=i
    i+=2
print(product)