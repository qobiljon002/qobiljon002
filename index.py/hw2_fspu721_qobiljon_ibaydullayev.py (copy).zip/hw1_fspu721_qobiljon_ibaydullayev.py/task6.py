num=int(input('Enter desired number.'))
if num%2==1:print('tub son.')
else:print('murakkab son.')