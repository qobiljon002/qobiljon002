# # # # nechta son kiritmoqchisiz?
# # # # birinchi sonni kiriting
nums=int(input('nechta son kiritmoqchisiz? '))
line=0
for i in range(nums):
    if nums>0:
        print( i+1, 'chi sonni kiriting')
    sum=int(input())
    line=(line+sum)
sum=line/nums 
print(sum, 'ga teng.')  

