num=input('enter the number')
sum=int(num)
print(num[::-1])
print(type(sum))
