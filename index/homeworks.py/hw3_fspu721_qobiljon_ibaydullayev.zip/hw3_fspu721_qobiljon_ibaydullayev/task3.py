num=int(input('enter the number'))
i=1
while i<=num:
    print('Current number is', i , 'and the cube is' , i**3)
    i+=1
