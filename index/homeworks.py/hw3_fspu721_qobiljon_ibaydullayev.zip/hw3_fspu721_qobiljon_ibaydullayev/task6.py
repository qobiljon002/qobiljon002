lst=['Sam','Lisa','Dave','Waytt','Emma','Sage']
i=0
while i<len(lst):
    print(lst[i])
    i+=1