for str in enumerate 'Antarctica':
    print(str, end='', sep='.')