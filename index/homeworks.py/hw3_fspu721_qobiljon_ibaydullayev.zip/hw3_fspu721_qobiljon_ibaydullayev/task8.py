text='hello world! it is python programming lenguage!'.split('p')
print(len(text)-1)

